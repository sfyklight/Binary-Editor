﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BinaryEditor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            openFileDialog1.FileName = "";
            openFileDialog1.ShowDialog();
            byte[] a =File.ReadAllBytes(openFileDialog1.FileName);
            richTextBox1.Text += BitConverter.ToString(a);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            saveFileDialog1.FileName = "";
            saveFileDialog1.ShowDialog();
            string byteString = richTextBox1.Text;
            string[] strArray = byteString.Split('-');
            byte[] w = new byte[strArray.Length];
            for (int i = 0; i < strArray.Length; i++)
            {
                w[i] = Convert.ToByte(strArray[i], 16);
                File.WriteAllBytes(saveFileDialog1.FileName, w);
            }
            pictureBox1.ImageLocation = saveFileDialog1.FileName;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                string byteString = richTextBox1.Text;
                string[] strArray = byteString.Split('-');
                byte[] w = new byte[strArray.Length];
                for (int i = 0; i < strArray.Length; i++)
                {
                    w[i] = Convert.ToByte(strArray[i], 16);
                   
                }
            }
            catch { }
           
        }
    }
}
